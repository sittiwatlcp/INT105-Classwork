/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package int102final_lab_exam2;

/**
 *
 * @author INT105
 */
public class NewMovieException extends Exception{

    public NewMovieException() {
    }

    public NewMovieException(String message) {
        super(message);
    }
    
}
