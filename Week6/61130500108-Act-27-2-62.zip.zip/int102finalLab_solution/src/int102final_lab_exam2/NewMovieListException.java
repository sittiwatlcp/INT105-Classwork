/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package int102final_lab_exam2;

/**
 *
 * @author INT105
 */
public class NewMovieListException extends RuntimeException{

    public NewMovieListException() {
    }

    public NewMovieListException(String message) {
        super(message);
    }
    
}
