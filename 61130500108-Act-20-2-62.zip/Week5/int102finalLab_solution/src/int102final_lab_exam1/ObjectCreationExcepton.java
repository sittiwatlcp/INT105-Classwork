/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package int102final_lab_exam1;

/**
 *
 * @author INT105
 */
public class ObjectCreationExcepton extends Exception {
    
    public ObjectCreationExcepton(String message) {
        super(message);
    }
    
}
